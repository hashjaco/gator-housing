import React, { Component } from 'react';

class Dashboard extends Component {
  render() {
    return (
      <div style={{marginTop:"2rem"}}>
        <p>(Dashboard goes here)</p>
      </div>
    )
  }
}

export default Dashboard;